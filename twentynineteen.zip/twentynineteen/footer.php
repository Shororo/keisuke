<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */

?><!doctype html>

<html lang="ja">
<head>
<meta charset="UTF-8">
<title>Xekeia</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shororo.css">
<script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<html>
<body>
<footer class="shadow">
<ul>
	<li><a href="#">PAGE-TOP</a></li>
	<li><a href="/">HOME</a></li>
</ul>
<ul>
	<li><a href="/#news">NEWS</a></li>
	<li><a href="/#what-to-see" class="smaller">WHAT to SEE</a></li>
	<li><a href="#">CONTACT</a></li>
</ul>
</footer>
</body>
</html>
