<!DOCTYPE html>
<html lang="ja">
<head>
	<meta charset="UTF-8">
	<title>Xekeia</title>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shororo.css" type="text/css">
	<!-- <link rel="stylesheet" href="assets/style.css"> -->
	<script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<body>
	<header>
		<!-- ドロップダウンメニュー -->
		<div class="menu">
			<!-- ラベルで属性「for」指定したidと関連付ける(チェックボックスやラジオボックスなどと) -->
			<label for="toggle"><i class="fas fa-5x fa-bars inlinemode padding-header1 shadow"></i></label>
			<input type="checkbox" id="toggle">
			<ul class="menu-second-level" style="visibility: hidden;">
				<li><a href="index.html">TOP</a></li>
				<li><a href="/nature">NATURE</a></li>
				<li><a href="/buildings">BUILDINGS</a></li>
				<li><a href="events.html">EVENTS &amp; FESTIVALS</a></li>
				<li><a href="index.html#news">NEWS</a></li>
			</ul>
		</div>

		<a href="/" class="inlinemode padding-header2 shadow"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/xgen.png" width="400px"></a>
		<i class="fas fa-5x fa-search inlinemode padding-header3 shadow"></i>
	</header>

	<div class="title" id="top-picture">
		<div class="trim">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/mountain.jpg" id="picture-title" alt="タイトル画像" title="タイトル画像">
		</div>
		<div class="letter-title shadow">
			<p>Welcome to </p>
			<h1>Xekeia</h1>
			<div class="sub-title">
				<p>mount. ASO</p>
				<hr>
				<p>DISCOVER MORE ⇒</p>
			</div>
		</div>
	</div>

	<!-- プルダウンメニュー -->
	<nav>
	</nav>

	<div class="midasi shadow">
		<hr class="title-hrw">
		<h1 class="midasi-f" id="what-to-see">WHAT to SEE</h1>
		<hr class="title-hr-rw">
	</div>
	<div class="what shadow">
		<div class="scroll">
			<ul>
				<li class="nature" id=>
					<a href="nature.html">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/siraito02.jpg" ><h2>NATURE</h2>
					</a>
				</li>
				<li id="picture-center" class="buildings">
					<a href="buildings.html">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/haikyo04.jpg"><h2>BUILDINGS</h2>
					</a>
				</li>
				<li class="fest">
					<a href="events.html">
						<img src="<?php echo get_template_directory_uri(); ?>/assets/images/hanabi.jpg"><h2>EVENTS &amp; FESTIVALS</h2>
					</a>
				</li>
			</ul>
		</div>
	</div>

	<div class="midasi shadow">
		<hr class="title-hr">
		<h1 class="midasi-f" id="news">NEWS</h1>
		<hr class="title-hr-r">
	</div>

	<div class="main">

		<!-- loop start -->
		<?php
		$args = array( 'post_type' => 'post' );
		$the_query = new WP_Query($args); if($the_query->have_posts()):
		?>
		<?php while ($the_query->have_posts()): $the_query->the_post(); ?>
			<div class="contents">
				<a href="<?php the_permalink(); ?>">
					<?php if(has_post_thumbnail()): ?>
						<img src="<?php the_post_thumbnail_url(); ?>"/>
						<?php else: ?>
							<img src="代替画像のURL"/>
						<?php endif; ?>
						<div class="contents-title shadow">
							<hr class="hr-white">
							<p><?php echo get_the_title(); ?></p>
						</div>
					</a>
				</div>
			<?php endwhile; ?>
			<?php wp_reset_postdata(); ?>
			<?php else: ?>
				<!-- 投稿が無い場合の処理 -->
			<?php endif; ?>
			<!-- loop end -->

		</div>

		<footer>
			<ul>
				<li><a href="#top-picture">TOP</a></li>
				<li><a href="#what-to-see">WHAT to SEE</a></li>
				<li><a href="#news">NEWS</a></li>
			</ul>
		</footer>
	</body>
	</html>