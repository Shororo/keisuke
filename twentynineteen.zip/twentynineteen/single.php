<!DOCTYPE html>
<head>
	<meta charset="UTF-8">
	<title>Xekeia-TOUKOU</title>
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shororo.css">
	<script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<body>

<?php get_header(); ?>

	<!-- ループかかないとコンテンツ取ってこれない -->
<?php if ( have_posts() ) : ?>
  <?php while( have_posts() ) : the_post(); ?>

	<div class="midasi categoly shadow">
		<hr class="title-hr">
		<h1 class="midasi-f" id="news"><?php the_title(); ?></h1>
		<hr class="title-hr-r">
	</div>

	<div class="main">
		<div class="contents">
			<img src="<?php the_post_thumbnail_url(); ?>" class="eyecatch">
			<div class="bunshou">
				<ul>
					<li>場所</li>
					<li><time>2011-12-03</time></li>
				</ul>
				<p><?php the_content(); ?></p>
				
				

			</div>
		</div>
		<div class="contents">
			<img src="picture/kouyou.jpg" alt="">
			<div class="bunshou">
				<h3>強調文</h3>
				<p>内容</p>
			</div>
		</div>
		<div class="contents">
			<img src="picture/kouyou.jpg" alt="">
			<div class="bunshou">
				<h3>強調文</h3>
				<p>内容</p>
			</div>
		</div>

		<div class="outside">
			<div class="sns">
				<a href="https://www.instagram.com/explore/tags/%E5%8D%97%E9%98%BF%E8%98%87/">
					<i class="fab fa-5x fa-instagram insta"></i>
					<p>Instagram</p>
				</a>
			</div>
			<div class="sns">
				<a href="http://www.city.aso.kumamoto.jp/">
					<i class="fas fa-5x fa-globe"></i>
					<p>Offical Website</p>
				</a>
			</div>
		</div>
	</div>

  <?php endwhile;?>
<?php endif; ?>


	<?php get_footer(); ?>

 

</body>
