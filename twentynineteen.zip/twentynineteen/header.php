<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */
?><!doctype html>

<html lang="ja">
<head>
<meta charset="UTF-8">
<title>Xekeia</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shororo.css">
<script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<body>

<header>
	<!-- ドロップダウンメニュー -->
	<div class="menu">
	<!-- ラベルで属性「for」指定したidと関連付ける(チェックボックスやラジオボックスなどと) -->
  	<label for="toggle"><i class="fas fa-5x fa-bars inlinemode padding-header1 shadow"></i></label>
  	<input type="checkbox" id="toggle">
<ul class="menu-second-level" style="visibility: hidden;">
<?php
// パラメータを指定
$args = array(
    // カテゴリー内の記事数順で指定
    'orderby' => 'count',
    // 降順で指定
    'order' => 'DSC'
);
$categories = get_categories( $args );

foreach( $categories as $category ){
    echo '<li><a href="' . get_category_link( $category->term_id ) . '">' . $category->name . '</a> </li> ';
}
?>
</ul>

		
	</div>

	<a href="/" class="inlinemode padding-header2 shadow"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/xgen.png" width="400px"></a>
	<i class="fas fa-5x fa-search inlinemode padding-header3 shadow"></i>
</header>
</body>
</html>