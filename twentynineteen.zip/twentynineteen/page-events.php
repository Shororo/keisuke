<?php
/*
Template Name:events
*/
?>

<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>Xekeia-EVENTS</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shororo.css">
<script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<body>
<?php get_header(); ?>

<!-- プルダウンメニュー -->
<nav>
</nav>

<div class="midasi categoly shadow">
	<hr class="title-hre">
	<h1 class="midasi-ef" id="news">EVENTS &amp; FESTIVALS</h1>
	<hr class="title-hr-re">
</div>

<div class="main">
	<div class="contents">
		<a href="/single">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/kouyou.jpg" alt="">
			<div class="contents-title shadow">
				<hr class="hr-white">
				<p>picture-title</p>
			</div>
		</a>
	</div>
	<div class="contents">
		<a href="/single">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/kouyou.jpg" alt="">
			<div class="contents-title shadow">
				<hr class="hr-white">
				<p>picture-title</p>
			</div>
		</a>
	</div>
</div>

<?php get_footer(); ?>

</body>