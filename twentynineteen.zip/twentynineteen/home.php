<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>Xekeia</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shororo.css">
<script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<body>
<?php get_header(); ?>

<div class="title" id="top-picture">
	<div class="trim">
		<img src="<?php echo get_template_directory_uri(); ?>/assets/images/mountain.jpg" id="picture-title" alt="タイトル画像" title="タイトル画像">
	</div>
	<div class="letter-title shadow">
		<p>Welcome to </p>
		<h1>Xekeia</h1>
		<div class="sub-title">
			<p>mount. ASO</p>
			<hr>
			<p>DISCOVER MORE ⇒</p>
	</div>
	</div>
</div>
<!-- プルダウンメニュー -->
<nav>

</nav>

<div class="midasi shadow">
	<hr class="title-hrw">
	<h1 class="midasi-f" id="what-to-see">WHAT to SEE</h1>
	<hr class="title-hr-rw">
</div>
<div class="what shadow">
	<div class="scroll">
		<ul>
			<li class="nature" id=>
				<a href="/nature">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/siraito02.jpg" ><h2>NATURE</h2>
				</a>
			</li>
			<li id="picture-center" class="buildings">
				<a href="/buildings">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/haikyo04.jpg"><h2>BUILDINGS</h2>
				</a>
			</li>
			<li class="fest">
				<a href="/events">
					<img src="<?php echo get_template_directory_uri(); ?>/assets/images/hanabi.jpg"><h2>EVENTS &amp; FESTIVALS</h2>
				</a>
			</li>
		</ul>
	</div>
</div>



<div class="midasi shadow">
	<hr class="title-hr">
	<h1 class="midasi-f" id="news">NEWS</h1>
	<hr class="title-hr-r">
</div>

                <?php if ( have_posts() ) : ?>
  <?php while ( have_posts() ) : the_post(); ?>
<div class="main">
	<div class="contents">
		<a href="<?php the_permalink(); ?>">
        <img src="<?php the_post_thumbnail_url(); ?>" class="eyecatch">
		<div class="contents-title shadow">
		<hr class="hr-white">
        <!--シングルページタイトル-->
        <p><?php the_title(); ?></p>
		</div>
		</a>
    </div>
</div>
        <?php endwhile;?>
        <?php endif; ?>

<footer class="shadow">
<ul>
	<li><a href="#top-picture">TOP</a></li>
	<li><a href="#what-to-see">WHAT to SEE</a></li>
	<li><a href="#news">NEWS</a></li>
</ul>
</footer>
</body>
</html>
