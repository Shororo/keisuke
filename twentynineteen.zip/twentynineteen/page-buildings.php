<?php
/*
Template Name:buildings
*/
?>


<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>Xekeia-BUILDINGS</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shororo.css">
<script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<html>
<body>

<?php get_header(); ?>

<!-- プルダウンメニュー -->
<nav>
</nav>

<div class="midasi categoly shadow">
	<hr class="title-hrb">
	<h1 class="midasi-f" id="news">BUILDINGS</h1>
	<hr class="title-hr-rb">
</div>

<div class="main">
	<div class="contents">
		<a href="#">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/kouyou.jpg" alt="">
			<div class="contents-title shadow">
				<hr class="hr-white">
				<p>picture-title</p>
			</div>
		</a>
	</div>
	<div class="contents">
		<a href="#">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/kouyou.jpg" alt="">
			<div class="contents-title shadow">
				<hr class="hr-white">
				<p>picture-title</p>
			</div>
		</a>
	</div>
</div>

<?php get_footer(); ?>

</body>
</html>