<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package WordPress
 * @subpackage Twenty_Nineteen
 * @since 1.0.0
 */

get_header();
?>



	<?php if ( have_posts() ) : ?>
  <?php while ( have_posts() ) : the_post(); ?>
<div class="main">
	<div class="contents">
		<a href="<?php the_permalink(); ?>">
        <img src="<?php the_post_thumbnail_url(); ?>" class="eyecatch">
		<div class="contents-title shadow">
		<hr class="hr-white">
        <!--シングルページタイトル-->
        <p><?php the_title(); ?></p>
		</div>
		</a>
    </div>
</div>
        <?php endwhile;?>
        <?php endif; ?>

<!-- 条件分岐でカテゴリページ個別に画像や文字装飾を施せば、OK -->
        <?php if ( is_category('nature') ) : ?>
  <h1 style="color: red;">kkkkkk</h1>
<?php endif; ?>

<?php
get_footer();
