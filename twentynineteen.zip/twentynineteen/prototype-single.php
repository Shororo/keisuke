<!DOCTYPE html>
<head>
<meta charset="UTF-8">
<title>Xekeia-SINGLE</title>
<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/shroro.css" type="text/css" /><script src="https://kit.fontawesome.com/7c414374ac.js" crossorigin="anonymous"></script>
</head>

<body>
<header>
	<!-- ドロップダウンメニュー -->
	<div class="menu">
	<!-- ラベルで属性「for」指定したidと関連付ける(チェックボックスやラジオボックスなどと) -->
  	<label for="toggle"><i class="fas fa-5x fa-bars inlinemode padding-header1 shadow"></i></label>
  	<input type="checkbox" id="toggle">
		<ul class="menu-second-level" style="visibility: hidden;">
			<li><a href="index.html">TOP</a></li>
			<li><a href="/nature">NATURE</a></li>
			<li><a href="buildings.html">BUILDINGS</a></li>
			<li><a href="events.html">EVENTS &amp; FESTIVALS</a></li>
			<li><a href="index.html#news">NEWS</a></li>
		</ul>
	</div>

	<a href="/" class="inlinemode padding-header2 shadow"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/xgen.png" width="400px"></a>
	<i class="fas fa-5x fa-search inlinemode padding-header3 shadow"></i>
</header>



<!-- プルダウンメニュー -->
<nav>
</nav>

<div class="midasi categoly shadow">
	<hr class="title-hr">


<?php if(have_posts()): the_post(); ?>
<article <?php post_class( 'article-content' ); ?>>
  <div class="article-info">
 <h1 class="midasi-f" id="news"><?php the_title(); ?></h1> 
</article>
<?php endif; ?>



	<h1 class="midasi-f" id="news">SINGLEPAGE TITLE</h1>
	


	<hr class="title-hr-r">
</div>

<div class="main">
	<div class="contents">

		<?php if( has_post_thumbnail() ): ?>
      <?php the_post_thumbnail( 'large' ); ?>
    <?php endif; ?>
		<div class="bunshou">
			<h2>画像タイトル</h2>
			<ul>
				<li>場所</li>
				<li><time>2011-12-03</time></li>
			</ul>
			<p><?php the_content(); ?></p>
		</div>
	</div>
	<div class="contents">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/kouyou.jpg" alt="">
		<div class="bunshou">
			<h3>強調文</h3>
			<p>内容</p>
		</div>
	</div>
	<div class="contents">
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/kouyou.jpg" alt="">
		<div class="bunshou">
			<h3>強調文</h3>
			<p>内容</p>
		</div>
	</div>
	
	<div class="outside">
		<div class="sns">
			<a href="https://www.instagram.com/explore/tags/%E5%8D%97%E9%98%BF%E8%98%87/">
			<i class="fab fa-5x fa-instagram insta"></i>
			<p>Instagram</p>
			</a>
		</div>
		<div class="sns">
			<a href="http://www.city.aso.kumamoto.jp/">
			<i class="fas fa-5x fa-globe"></i>
			<p>Offical Website</p>
			</a>
		</div>
	</div>
</div>

<footer>
<ul>
	<li><a href="#">TOP</a></li>
	<li><a href="index.html#news">NEWS</a></li>
	<li><a href="nature.html">NATURE</a></li>
</ul>
<ul>
	<li><a href="buildings.html">BUILDINGS</a></li>
	<li><a href="events.html">EVENTS &amp; FESTIVALS</a></li>
</ul>
</footer>
</body>